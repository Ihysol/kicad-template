*PADS-LIBRARY-PART-TYPES-V9*

MCP4921-E_SN SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.11.03.10.19.34
"Mouser Part Number" 579-MCP4921-E/SN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP4921-E-SN?qs=W2ndVjZwIIIOYoIsyQyMYw%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP4921-E/SN
"Description" Single 12-bit DAC SPI I/F,MCP4921-E/SN
"Datasheet Link" http://ww1.microchip.com/downloads/en/DeviceDoc/22248a.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
MCP4921-E_SN
1 0 U VDD
2 0 U \CS
3 0 U SCK
4 0 U SDI
8 0 U VOUT
7 0 U VSS
6 0 U VREF
5 0 U \LDAC

*END*
*REMARK* SamacSys ECAD Model
159286/816773/2.50/8/3/Integrated Circuit
